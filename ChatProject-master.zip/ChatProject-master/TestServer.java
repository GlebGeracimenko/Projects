package week4.ChatProject;


/**
 * Created by Виталий on 11.02.2015.
 */
public class TestServer {

    public static void main(String[] args) {
        My_ServerSocket serverSocket=new My_ServerSocket();
        serverSocket.start();
    }
}
